
package oop_project;

public class OOP_PROJECT {

    
    public static void main(String[] args)
    {
       WELCOME_PAGE E= new WELCOME_PAGE() ; 
    }
    
}
